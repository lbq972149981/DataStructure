package ccf;

import java.util.Scanner;

public class 排列 {
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
         int t = sc.nextInt();
         while(t-->0)
         {
            int a[] = new int[100010];
            int n = sc.nextInt();
            int k = sc.nextInt();
            for(int i=0;i<n;i++) {
               a[i] = sc.nextInt();
            }
      }
   }
}
