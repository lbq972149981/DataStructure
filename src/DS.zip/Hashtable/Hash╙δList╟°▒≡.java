package Hashtable;

public class Hash与List区别 {
   /*
   List集合:元素有序，可重复
   Hash集合:元素无序，不可重复
    */
}
