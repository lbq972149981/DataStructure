package Search;

public class 斐波那契查找 {
   /**
    * 公式：mid = low + F[k-1]-1
    * 只涉及加减法，不使用除法
    * 除法所占用的时间比加减法占用的时间要多
    */
}
